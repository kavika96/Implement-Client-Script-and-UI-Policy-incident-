# Implement Client Script & UI Policy – Incident

## Project Overview
This project demonstrates the implementation and testing of UI Policy and different Client Script types in ServiceNow using the Incident table.

## Milestones
1. Create UI Policy on Incident
2. Create UI Policy Action – Urgency
3. Create onChange Client Script
4. Create onSubmit Client Script (Save Validation)
5. Create onCellEdit Client Script
6. Testing the Configuration

## Documentation
The complete project documentation is available here:

[ServiceNow Client Script & UI Policy Documentation](Documentation/ServiceNow_Client_Script_UI_Policy_Incident_Documentation.docx)

## Screenshots
Add the ServiceNow screenshots for each milestone to the `Screenshots` folder.

Suggested names:
- `milestone1-ui-policy.png`
- `milestone2-ui-policy-action-urgency.png`
- `milestone3-onchange-client-script.png`
- `milestone4-onsubmit-client-script.png`
- `milestone5-oncelledit-client-script.png`
- `milestone6-testing.png`

## Technologies Used
- ServiceNow
- Incident Management
- UI Policy
- UI Policy Action
- Client Script
- JavaScript

## Project Outcome
Successfully implemented and tested UI Policy and multiple Client Script configurations in ServiceNow.
